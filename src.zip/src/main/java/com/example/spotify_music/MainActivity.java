package com.example.spotify_music;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();

        setContentView(R.layout.activity_main);
        bottomNavigationView = findViewById(R.id.bottomNav);
        bottomNavigationView.setOnNavigationItemSelectedListener(bottomNavMethod);
        getSupportFragmentManager().beginTransaction().replace(R.id.container,new home()).commit();

    }
        private BottomNavigationView.OnNavigationItemSelectedListener bottomNavMethod=new
                BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                Fragment fragment=null;

                switch(menuItem.getItemId())
                {
                    case R.id.home:
                        fragment=new home();
                        break;


                    case R.id.search:
                        fragment=new search();
                        break;



                    case R.id.library:
                        fragment=new library();
                        break;



                    case R.id.premium:
                        fragment=new premium();
                        break;

                }
                getSupportFragmentManager().beginTransaction().replace(R.id.container,fragment).commit();



                return false;
            }
        };
            }