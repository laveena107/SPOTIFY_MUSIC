package com.example.spotify_music;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;

public class choosemood extends AppCompatActivity {
    ImageView iv, iv2,iv3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_choosemood);
        ImageView iv = (ImageView)findViewById(R.id.imageView17);
        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), voicesearch.class);
                startActivity(i);

            }
        });
        ImageView iv2 = (ImageView)findViewById(R.id.imageView18);
        iv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1 = new Intent(getApplicationContext(), Camera.class);
                startActivity(i1);

            }
        });
        iv3=findViewById(R.id.imageView11);
        iv3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2 = new Intent(getApplicationContext(), Playlist.class);
                startActivity(i2);
            }
        });


    }
}